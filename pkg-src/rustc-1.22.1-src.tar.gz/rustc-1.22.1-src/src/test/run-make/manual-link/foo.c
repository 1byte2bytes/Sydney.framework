// ignore-license
void bar() {}
