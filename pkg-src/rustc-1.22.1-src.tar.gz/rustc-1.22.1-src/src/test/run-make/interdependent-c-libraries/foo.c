// ignore-license
void foo() {}
