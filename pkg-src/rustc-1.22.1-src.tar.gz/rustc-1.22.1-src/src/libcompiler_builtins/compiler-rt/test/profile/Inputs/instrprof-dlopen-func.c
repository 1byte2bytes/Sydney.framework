void func(int K) { if (K) {} }
