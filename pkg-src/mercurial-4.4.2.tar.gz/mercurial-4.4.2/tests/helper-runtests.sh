#
# Avoid interference from actual test env:

unset HGTEST_JOBS
unset HGTEST_TIMEOUT
unset HGTEST_PORT
unset HGTEST_SHELL
